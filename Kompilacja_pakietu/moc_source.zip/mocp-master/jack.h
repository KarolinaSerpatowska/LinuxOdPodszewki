#ifndef JACK_H
#define JACK_H

#ifdef __cplusplus
extern "C" {
#endif

void moc_jack_funcs (struct hw_funcs *funcs);

#ifdef __cplusplus
}
#endif

#endif
