#ifndef NULL_OUT_H
#define NULL_OUT_H

#ifdef __cplusplus
extern "C" {
#endif

void null_funcs (struct hw_funcs *funcs);

#ifdef __cplusplus
}
#endif

#endif
