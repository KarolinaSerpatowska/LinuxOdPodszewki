#ifndef SNDIO_OUT_H
#define SNDIO_OUT_H

#include "audio.h"

#ifdef __cplusplus
extern "C" {
#endif

void sndio_funcs (struct hw_funcs *funcs);

#ifdef __cplusplus
}
#endif

#endif
