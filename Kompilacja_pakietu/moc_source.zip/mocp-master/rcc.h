#ifndef RCC_H
#define RCC_H

#ifdef __cplusplus
extern "C" {
#endif

char *rcc_reencode (char *);
void rcc_init ();
void rcc_cleanup ();

#ifdef __cplusplus
}
#endif

#endif
