#ifndef ALSA_H
#define ALSA_H

#ifdef __cplusplus
extern "C" {
#endif

void alsa_funcs (struct hw_funcs *funcs);

#ifdef __cplusplus
}
#endif

#endif
