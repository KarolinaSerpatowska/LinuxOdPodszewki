#ifndef OSS_H
#define OSS_H

#include "audio.h"

#ifdef __cplusplus
extern "C" {
#endif

void oss_funcs (struct hw_funcs *funcs);

#ifdef __cplusplus
}
#endif

#endif
